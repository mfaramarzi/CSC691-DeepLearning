#import os

#directory = 'uncorrected-YOLO_darknet'
#for a_file in os.listdir(directory):
  #for line in a_file:

#input file
fin = open("data.txt", "rt")
#output file to write the result to
fout = open("out.txt", "wt")
#for each line in the input file
for line in fin:
	#read replace the string and write to output file
	fout.write(line.replace('6', '5'))
	fout.write(line.replace('9', '6'))
	fout.write(line.replace('10', '7'))
	fout.write(line.replace('11', '8'))
	fout.write(line.replace('8', '5'))
#close input and output files
fin.close()
fout.close()