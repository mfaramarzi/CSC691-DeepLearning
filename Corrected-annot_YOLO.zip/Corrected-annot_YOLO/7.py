import os

dirname = "/home/masoud/masoud/Dataset/PID-CORRECTED/uncorrected-YOLO_darknet"
for txt_in in os.listdir(dirname):
    with open(os.path.join(dirname, txt_in), 'r') as f:
        infile = f.read()# Read contents of file
        for line in infile.split('\n') :
            word=line.split(" ")[0]#spliting the string and returning an array and returing the first item of array
            if word=="6":
                word=word.replace('6', '5')#it is only changing the word but not in the infile
            elif word=="9":
                word=word.replace('9', '6')
            elif word=="10":
                word=word.replace('10', '7')
            elif word=="11":
                word=word.replace('11', '8')
                #If the break statement is inside a nested loop (loop inside another loop), the break statement will terminate the innermost loop.
            else:
                continue
        with open(os.path.join(dirname, txt_in), 'w') as f:
            f.write(infile)
            break 