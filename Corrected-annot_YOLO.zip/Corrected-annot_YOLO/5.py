import os

for txt_in in os.listdir(r"uncorrected-YOLO_darknet"):#https://www.newbedev.com/python/howto/how-to-iterate-over-files-in-a-given-directory/ 
    with open(txt_in) as infile:# In addition, it will automatically close the file. The with statement provides a way for ensuring that a clean-up is always used.
        for line in infile:
            word=line.split(" ")[0]#spliting the string and returning an array and returing the first item of array
            if word=="6":
                word.replace('6', '5')#should i use if statement?
            elif word=="9":
                word.replace('9', '6')
            elif word=="10":
                word.replace('10', '7')
            elif word=="11":
                word.replace('11', '8')#how does it close one txt and open the next one?
                #If the break statement is inside a nested loop (loop inside another loop), the break statement will terminate the innermost loop.
            else:
                continue
            break
