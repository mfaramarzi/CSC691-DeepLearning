replacements = {'6':'5', '9':'6', '10':'7', '11':'8', '8':'5'}

with open('data.txt') as infile, open('out.txt', 'w') as outfile:
    for line in infile:
    	word, tail = line.split(" ", 1)
	if word in replacements:
  	word = replacements[word]

outfile.write(word + " " + tail)

#TabError: inconsistent use of tabs and spaces in indentation