import os

dirname = "/home/masoud/masoud/Dataset/PID-CORRECTED/uncorrected-YOLO_darknet"
for txt_in in os.listdir(dirname):
    with open(os.path.join(dirname, txt_in), 'r') as f:
        # Don't read entire file since we
        # are looping line by line
        #infile = f.read()# Read contents of file
        result = []
        for line in f:  # changed to file handle
            line = line.rstrip() # remove trailing '\n'
            # Only split once since you're only check the first word
            words = line.split(" ", maxsplit = 1)
            word = words[0]  # word 0 may change
            if word == "6":
                word = word.replace('6', '5')
            elif word=="9":
                word = word.replace('9', '6')
            elif word == "10":
                word = word.replace('10', '7')
            elif word == "11":
                word = word.replace('11', '8')
            else:
                pass
            # Update the word you modified
            words[0] = word  # update word 0
            # save new line into results
            # after converting back to string
            result.append(" ".join(words))

    with open(os.path.join(dirname, txt_in), 'w') as f:
        # Convert result list to string and write to file
        outfile = '\n'.join(result)
        f.write(outfile)