replacements = {'6':'5', '9':'6', '10':'7', '11':'8', '8':'5'}

with open('data.txt') as infile, open('out.txt', 'w') as outfile:
    for line in infile:
        for src, target in replacements.items():
            line = line.replace(src, target)
        outfile.write(line)

#it replaced all numbers not only the label