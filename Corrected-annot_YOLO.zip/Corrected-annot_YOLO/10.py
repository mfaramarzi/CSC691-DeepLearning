import os

dirname = "/home/masoud/masoud/Dataset/PID-CORRECTED/uncorrected-YOLO_darknet"

for txt_in in os.listdir(dirname):
    with open(os.path.join(dirname, txt_in), 'r+') as f:
        infile = f.readlines()# Read contents of file
        d=[]
        for line in infile:
            word = line.split(" ")
            if word[0]=="6":
                word[0]="5"
            elif word[0]=="9":
                word[0]= '6'
            elif word[0]=="10":
                word[0]= '7'
            elif word[0]=="11":
                word[0]= '8'
            d.append(" ".join(word))
        if len(d)!=0:
            f.seek(len(infile)-2)
            f.writelines(d)