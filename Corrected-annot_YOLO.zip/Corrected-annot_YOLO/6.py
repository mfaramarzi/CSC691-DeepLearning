import os

dirname = "/home/masoud/masoud/Dataset/PID-CORRECTED/uncorrected-YOLO_darknet"
for txt_in in os.listdir(dirname):
    with open(os.path.join(dirname, txt_in)) as infile:
        for line in infile:
            word=line.split(" ")[0]#spliting the string and returning an array and returing the first item of array
            if word=="6":
                word=word.replace('6', '5')#should i use if statement?
            elif word=="9":
                word=word.replace('9', '6')
            elif word=="10":
                word=word.replace('10', '7')
            elif word=="11":
                word=word.replace('11', '8')#how does it close one txt and open the next one?
                #If the break statement is inside a nested loop (loop inside another loop), the break statement will terminate the innermost loop.
            else:
                continue
            break